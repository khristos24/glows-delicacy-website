import { useState } from 'react';
import { X } from 'lucide-react';

export function GalleryPage() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const galleryImages = [
    {
      url: 'https://images.unsplash.com/photo-1664992960082-0ea299a9c53e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      alt: 'Jollof Rice',
      featured: true,
    },
    {
      url: 'https://images.unsplash.com/photo-1741026079032-7cb660e44bad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      alt: 'Egusi Soup',
    },
    {
      url: 'https://images.unsplash.com/photo-1708585869478-e53fa19a1a63?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      alt: 'Fried Rice with Shrimp',
      featured: true,
    },
    {
      url: 'https://images.unsplash.com/photo-1623169495444-2a2793212500?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      alt: 'Small Chops',
    },
    {
      url: 'https://images.unsplash.com/photo-1647275555893-0536f9990b45?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      alt: 'Meat Pies',
    },
    {
      url: 'https://images.unsplash.com/photo-1611695500858-e6ac19b1ca55?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      alt: 'Coconut Rice',
      featured: true,
    },
    {
      url: 'https://images.unsplash.com/photo-1584440772680-63bec399984b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      alt: 'Food Tray',
    },
    {
      url: 'https://images.unsplash.com/photo-1744957280662-af6472128abd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      alt: 'Lunch Box',
    },
    {
      url: 'https://images.unsplash.com/photo-1767335911106-b96c1cc33099?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      alt: 'Baked Goods',
    },
    {
      url: 'https://images.unsplash.com/photo-1653981608672-aea09b857b20?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      alt: 'Nigerian Rice Dish',
      featured: true,
    },
    {
      url: 'https://images.unsplash.com/photo-1702827482556-481adcd68f3b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
      alt: 'Traditional Cuisine',
    },
  ];

  return (
    <div className="min-h-screen py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-[#d4af37] mb-6">
            Our Gallery
          </h1>
          <div className="w-24 h-1 bg-[#d4af37] mx-auto mb-8"></div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            A visual feast showcasing our delicious dishes and memorable moments
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryImages.map((image, index) => (
            <div
              key={index}
              className={`
                ${image.featured ? 'lg:col-span-2 lg:row-span-2' : ''}
                relative rounded-2xl overflow-hidden border border-[#d4af37]/20 
                hover:border-[#d4af37]/50 transition-all cursor-pointer group
              `}
              onClick={() => setSelectedImage(image.url)}
            >
              <div className={`aspect-square ${image.featured ? 'lg:aspect-video' : ''} overflow-hidden`}>
                <img
                  src={image.url}
                  alt={image.alt}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all flex items-center justify-center">
                  <span className="text-white opacity-0 group-hover:opacity-100 transition-all text-lg">
                    Click to view
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <p className="text-gray-300 mb-6">
            Want to see more of our delicious creations? Follow us on social media!
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <a
              href="https://instagram.com/glows_delicacy"
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 bg-[#1a1a1a] border border-[#d4af37]/30 text-[#d4af37] rounded-full hover:bg-[#d4af37] hover:text-black transition-all"
            >
              @glows_delicacy
            </a>
            <a
              href="https://facebook.com/glory.archibong"
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 bg-[#1a1a1a] border border-[#d4af37]/30 text-[#d4af37] rounded-full hover:bg-[#d4af37] hover:text-black transition-all"
            >
              Glory Archibong
            </a>
          </div>
        </div>
      </div>

      {/* Lightbox */}
      {selectedImage && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <button
            className="absolute top-4 right-4 p-2 bg-[#d4af37] text-black rounded-full hover:bg-[#f5d877] transition-all"
            onClick={() => setSelectedImage(null)}
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={selectedImage}
            alt="Gallery preview"
            className="max-w-full max-h-full object-contain rounded-lg"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}
