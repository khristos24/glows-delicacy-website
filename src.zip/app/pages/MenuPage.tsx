import { MessageCircle } from 'lucide-react';

interface MenuItem {
  name: string;
  price?: string;
  image: string;
}

export function MenuPage() {
  const menuCategories = [
    {
      category: 'Daily Plates',
      description: 'Fresh, homemade meals served daily',
      items: [
        {
          name: 'Jollof Rice Special',
          price: '₦3,500',
          image: 'https://images.unsplash.com/photo-1664992960082-0ea299a9c53e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
        },
        {
          name: 'Premium Daily Plate',
          price: '₦5,000',
          image: 'https://images.unsplash.com/photo-1653981608672-aea09b857b20?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
        },
      ],
    },
    {
      category: 'Soups',
      description: 'Traditional Nigerian soups made with authentic recipes',
      items: [
        {
          name: 'Egusi Soup',
          price: '₦5,000',
          image: 'https://images.unsplash.com/photo-1741026079032-7cb660e44bad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
        },
        {
          name: 'Afang Soup',
          image: 'https://images.unsplash.com/photo-1741026079032-7cb660e44bad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
        },
        {
          name: 'Banga Soup',
          image: 'https://images.unsplash.com/photo-1584440772680-63bec399984b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
        },
        {
          name: 'Okro Seafood',
          image: 'https://images.unsplash.com/photo-1741026079032-7cb660e44bad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
        },
        {
          name: 'Vegetable Soup',
          image: 'https://images.unsplash.com/photo-1741026079032-7cb660e44bad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
        },
      ],
    },
    {
      category: 'Rice Dishes',
      description: 'Flavorful rice dishes prepared to perfection',
      items: [
        {
          name: 'Jollof Rice',
          image: 'https://images.unsplash.com/photo-1664992960082-0ea299a9c53e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
        },
        {
          name: 'Fried Rice with Shrimp',
          price: '₦5,000',
          image: 'https://images.unsplash.com/photo-1708585869478-e53fa19a1a63?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
        },
        {
          name: 'Coconut Rice with Shrimps',
          image: 'https://images.unsplash.com/photo-1611695500858-e6ac19b1ca55?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
        },
      ],
    },
    {
      category: 'Native Dishes',
      description: 'Authentic traditional Nigerian specialties',
      items: [
        {
          name: 'Ekpang-Nkukwo',
          image: 'https://images.unsplash.com/photo-1702827482556-481adcd68f3b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
        },
      ],
    },
    {
      category: 'Small Chops & Pastries',
      description: 'Perfect for events and quick bites',
      items: [
        {
          name: 'Small Chops Platter',
          image: 'https://images.unsplash.com/photo-1623169495444-2a2793212500?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
        },
        {
          name: 'Meat Pies',
          price: 'From ₦500',
          image: 'https://images.unsplash.com/photo-1647275555893-0536f9990b45?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
        },
        {
          name: 'Premium Baked Goods',
          image: 'https://images.unsplash.com/photo-1767335911106-b96c1cc33099?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
        },
      ],
    },
    {
      category: 'Trays & Lunch Boxes',
      description: 'Perfect for celebrations and events',
      items: [
        {
          name: 'Maxi Food Tray',
          image: 'https://images.unsplash.com/photo-1584440772680-63bec399984b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
        },
        {
          name: 'Celebration Lunch Box',
          image: 'https://images.unsplash.com/photo-1744957280662-af6472128abd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
        },
      ],
    },
  ];

  return (
    <div className="min-h-screen py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-[#d4af37] mb-6">
            Our Menu & Packages
          </h1>
          <div className="w-24 h-1 bg-[#d4af37] mx-auto mb-8"></div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Explore our wide selection of authentic Nigerian dishes, baked goods, and special packages
          </p>
        </div>

        {/* Menu Categories */}
        <div className="space-y-16">
          {menuCategories.map((category, idx) => (
            <div key={idx}>
              <div className="mb-8">
                <h2 className="text-3xl font-bold text-[#d4af37] mb-2">{category.category}</h2>
                <p className="text-gray-400">{category.description}</p>
              </div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {category.items.map((item, index) => (
                  <MenuCard key={index} item={item} />
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-20 bg-gradient-to-r from-[#1a1a1a] to-[#2a2a2a] rounded-3xl p-8 md:p-12 border border-[#d4af37]/30 text-center">
          <h2 className="text-3xl font-bold text-[#d4af37] mb-4">
            Custom Orders & Full Catalog
          </h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Looking for something specific or need a custom package? Contact us on WhatsApp 
            for our full catalog and personalized meal options tailored to your needs.
          </p>
          <a
            href="https://wa.me/2348164334163"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-[#d4af37] text-black rounded-full hover:bg-[#f5d877] transition-all transform hover:scale-105"
          >
            <MessageCircle className="w-5 h-5" />
            <span>Contact Us on WhatsApp</span>
          </a>
        </div>
      </div>
    </div>
  );
}

function MenuCard({ item }: { item: MenuItem }) {
  return (
    <div className="bg-[#1a1a1a] rounded-2xl overflow-hidden border border-[#d4af37]/20 hover:border-[#d4af37]/50 transition-all hover:transform hover:scale-105 group">
      <div className="aspect-[3/4] overflow-hidden">
        <img
          src={item.image}
          alt={item.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
        />
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold text-white mb-2">{item.name}</h3>
        {item.price && (
          <p className="text-[#d4af37] font-semibold">{item.price}</p>
        )}
        {!item.price && (
          <p className="text-gray-400 text-sm">Contact for pricing</p>
        )}
      </div>
    </div>
  );
}
